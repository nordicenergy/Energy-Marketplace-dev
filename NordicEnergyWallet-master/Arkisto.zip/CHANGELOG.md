#### 0.0.0-development (2018-10-15)

##### New Features

*  Associate Meta-Information to accounts by address. Signed by user ([4fc3e57d](https://github.com/energychain/CorrentlyWallet/commit/4fc3e57d901527a3535490534ffaea14a989ee42))

#### 0.0.0-development (2018-10-15)

#### 0.0.0-development (2018-10-15)

